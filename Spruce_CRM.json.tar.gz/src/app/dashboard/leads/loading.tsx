import CrmLoading from "../crm/loading";

export default CrmLoading;
